#include "definition.hpp"

CNF readCNF(const char* filename) {
    FILE* file = fopen(filename, "r");
    if (!file) {
        printf("�޷����ļ�: %s\n", filename);
        return NULL;
    }
    
    CNF cnf = (CNF)malloc(sizeof(cnfNode));
    if (!cnf) {
        fclose(file);
        return NULL;
    }
    
    cnf->root = NULL;
    cnf->boolCount = 0;
    cnf->clauseCount = 0;
    
    char line[1024];
    clauseList lastClause = NULL;
    
    while (fgets(line, sizeof(line), file)) {
        // ����ע���кͿ���
        if (line[0] == 'c' || line[0] == '\n') {
            continue;
        }
        
        // ��������
        if (line[0] == 'p') {
            char format[10];
            sscanf(line, "p %s %d %d", format, &cnf->boolCount, &cnf->clauseCount);
            continue;
        }
        
        // �����Ӿ�
        clauseNode* newClause = (clauseNode*)malloc(sizeof(clauseNode));
        if (!newClause) {
            fclose(file);
            destroyCNF(cnf);
            return NULL;
        }
        
        newClause->head = NULL;
        newClause->next = NULL;
        
        // ����ǵ�һ���Ӿ䣬����Ϊ���ڵ�
        if (!cnf->root) {
            cnf->root = newClause;
            lastClause = newClause;
        } else {
            lastClause->next = newClause;
            lastClause = newClause;
        }
        
        // ��������
        char* token = strtok(line, " \t\n");
        literalList lastLiteral = NULL;
        
        while (token) {
            int literal = atoi(token);
            
            // ����0��ʾ�Ӿ����
            if (literal == 0) {
                break;
            }
            
            literalNode* newLiteral = (literalNode*)malloc(sizeof(literalNode));
            if (!newLiteral) {
                fclose(file);
                destroyCNF(cnf);
                return NULL;
            }
            
            newLiteral->literal = literal;
            newLiteral->next = NULL;
            
            if (!newClause->head) {
                newClause->head = newLiteral;
            } else {
                lastLiteral->next = newLiteral;
            }
            
            lastLiteral = newLiteral;
            token = strtok(NULL, " \t\n");
        }
    }
    printf("��ȡ��ɣ�\n");
    fclose(file);
    return cnf;
}

// ����CNF�ṹ
void destroyCNF(CNF cnf) {
    if (!cnf) return;
    
    clauseList currentClause = cnf->root;
    while (currentClause) {
        clauseList nextClause = currentClause->next;
        
        literalList currentLiteral = currentClause->head;
        while (currentLiteral) {
            literalList nextLiteral = currentLiteral->next;
            free(currentLiteral);
            currentLiteral = nextLiteral;
        }
        
        free(currentClause);
        currentClause = nextClause;
    }
    
    free(cnf);
}

// ��ӡCNF�ṹ
void printCNF(CNF cnf) {
    if (!cnf) {
        printf("CNFΪ��\n");
        return;
    }
    
    printf("p cnf %d %d\n", cnf->boolCount, cnf->clauseCount);
    
    clauseList currentClause = cnf->root;
    while (currentClause) {
        literalList currentLiteral = currentClause->head;
        
        while (currentLiteral) {
            printf("%d ", currentLiteral->literal);
            currentLiteral = currentLiteral->next;
        }
        
        printf("0\n");
        currentClause = currentClause->next;
    }
}
