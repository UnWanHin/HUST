该文档是关于代码自动测试的说明文档，将说明如何对自动测试程序进行配置。
1. 指定被测试源代码所在包
为了使得测试代码能顺利加载每个同学的class，第11-13章作业通过Javadoc API规定了每个类的类名、每个类的数据成员的类型和变量名、每个方法的方法名、形参类型、返回类型必须一致。除此之外，还必须统一包名。
11-13章编程题第二题，包名统一为package homework.ch11_13.p3;
11-13章编程题第三题，包名统一为package homework.ch11_13.p4;
在IDEA操作演示3.mp4里，演示了如果通过Refactor改变代码所在的包，是很简单的操作，但是一定要通过Refactor改变代码所在的包。如果直接修改包名，相关代码修改起来比较麻烦。
2. 测试代码的目录结构
测试代码的目录结构如图1所示：
图1 测试代码的目录结构
测试代码的根目录为AutoTest_update3。在该目录中，各文件和目录内容说明如下：
testng.xml，testng2.xml，testng3.xml为测试的配置信息；
test.bat是Windows运行测试程序的脚本文件，大家需要修改，如何修改见第3节；
test.sh是Linux/Mac运行测试程序的脚本文件，大家需要修改，如何修改见第3节；
test-output目录是测试结果报告的输出目录，该目录名不要修改，目录也别删除；
lib目录是测试程序运行所依赖的jar包，该目录名不要修改，目录也别删除；
betest目录是最后提交测试代码的目录，学生在本机测试时，可以不使用这个目录。但提交作业时，需要把作业的class文件拷贝到这个目录。具体说明见第5节。
请保持AutoTest_update3下的目录结构不变，AutoTest_update3目录可以位于任何位置。大家进入到该目录，运行test.bat就可以启动测试程序。如果是在Linux下或者Mac下面，目录结构和要求一样。
3. test.bat,test.sh,testing.xml的修改
用于Windows的test.bat脚本文件内容如图2所示：
必须修改为学生被测试代码所在包的上一级目录必须修改为学生被测试代码所在包的上一级目录必须修改所在机器的JAVA_HOME路径必须修改所在机器的JAVA_HOME路径
必须修改为学生被测试代码所在包的上一级目录
必须修改为学生被测试代码所在包的上一级目录
必须修改所在机器的JAVA_HOME路径
必须修改所在机器的JAVA_HOME路径
图2 Windows下运行脚本内容及所需修改地方
在test.bat里学生只需要修改环境变量JAVA_HOME和TO_BE_TEST_CLASSPAH，其他的环境变量如LIB_DIR、TEST_SUITE_CLASSPATH都是用的相对路径，所以无需修改。对用于Linux或Mac的脚本文件的修改一样，如图3所示：
必须修改为学生被测试代码所在包的上一级目录必须修改为学生被测试代码所在包的上一级目录必须修改所在机器的JAVA_HOME路径必须修改所在机器的JAVA_HOME路径
必须修改为学生被测试代码所在包的上一级目录
必须修改为学生被测试代码所在包的上一级目录
必须修改所在机器的JAVA_HOME路径
必须修改所在机器的JAVA_HOME路径
图3 Linux/Mac下运行脚本内容及所需修改地方
由于测试代码同时测试二个编程练习，因此有三个xml文件对测试过程进行配置。其中testng2.xml是对编程第2题的测试配置，testng3.xml是对编程第3题的测试配置。testng.xml则是将多个测试组合起来，其内容如下所示：
一般情况下这三个xml配置文件不需要修改。但是有的同学第3题没有完成，只能进行第2题的测试，这时需要修改testng.xml文件，将第3题的测试配置文件testng3.xml注释起来，xml文件注释用<!--  -->, 如下图所示：
这个时候测试代码只会执行第testng2.xml里面的测试。
测试代码是在JDK17下编译的，因此最好保持JDK版本一致。运行测试脚本时，测试目录不要包含中文路径。
4. 测试程序运行及查看测试结果
在命令行进入到AutoTest_update3目录，运行test.bat。运行结果如图3所示：
图3 命令行运行测试程序
这时进入到AutoTest_update3目录下的子目录test-output，里面内容如图4所示：
图5 test-output目录内容
打开index.html，可以看到测试结果，如图6所示：
图6 查看测试报告
测试报告会显示有二个Test Suit，第一个Test Suit测试一共测试了51个方法，51个Passed。第二个Test Suit一共测试了29个方法，29个Passed。如果有错误，会给出错误的方法，和导致错误的测试案例。
Linux下测试代码和运行脚本也经过测试，如图7所示：
图7 Linux下运行测试程序
5. 提交测试包
为了方便作业提交后助教对学生的代码测试，学生需要把作业编译后的class文件拷贝到AutoTest_update3下的betest目录下。以11-13章编程题第二题为例，由于规定了包名必须是homework.ch11_13.p3，因此betest的子目录结构应该如图8所示：
图8 betest的目录结构
学生则将工程编译好的这个包下面的class文件拷贝到p3子目录下。同时，将测试脚本里TO_BE_TEST_CLASSPAH的目录设置成相对目录。
对于Windows脚本test.bat，相应语句改为：
set TO_BE_TEST_CLASSPAH=.\betest
对于Linux/Mac脚本test.bat，相应语句改为：
TO_BE_TEST_CLASSPAH=./betest
注意斜杠前面有一个. ，表示当前目录。
类似地，第三题作业拷贝到betest\homework\ch11_13\p4包下面。
最后把AutoTest_update3打包，随同作业源代码(.java文件)、作业客观题答案一起提交。在将AutoTest_update3打包提交前，学生应该在本机运行修改后的脚本，确保测试代码可以测试betest下面的class文件。
在提交AutoTest_update3包前，测试代码脚本的TO_BE_TEST_CLASSPAH的目录可以指向工程目录里的包，如第3节所示，这样可以方便学生根据测试结果修改调试代码。
6. 测试运行的JDK版本问题
由于测试代码是在控制台下运行而不是在IDEA里运行，所以要保证从控制台运行时启动java程序的JDK版本为JDK17。验证方法是在控制台运行java -version，如下图所示：