import pygame
import csv
import os
import time
import math
import random
import sys  # 🔥 1. 新增這行：為了能強制退出程式
from settings import *
from entities import Base, Ant, Food, Wall, Stronghold, reset_game_environment

DATA_DIR = 'data'
CSV_FILE = os.path.join(DATA_DIR, 'training_results.csv')
if not os.path.exists(DATA_DIR): os.makedirs(DATA_DIR)

# 🔥 1. 將常數定義移到全域，防止 NameError
ATTACK_REACH = 10 * SCALE
ATTACK_COOLDOWN = 1
MEDIC_COOLDOWN = 10


def load_latest_gene():
    default_gene = [0.5, 0.4, 0.2, 0.2, 0.2, 0.5, 0.5, 0.5]
    if not os.path.exists(CSV_FILE): return default_gene, default_gene
    try:
        with open(CSV_FILE, 'r') as f:
            lines = list(csv.reader(f))
            if len(lines) < 2: return default_gene, default_gene
            last = lines[-1]
            winner = last[1]
            try:
                r = eval(last[2])
                b = eval(last[3])

                def fix(g):
                    if not isinstance(g, list): g = default_gene
                    if len(g) < 8: g += default_gene[len(g):]
                    return g[:8]

                if winner == 'RED':
                    return fix(r), fix(b)
                else:
                    return fix(b), fix(b)
            except:
                return default_gene, default_gene
    except:
        return default_gene, default_gene


def calculate_score(base, enemy_base):
    score = (base.hp - enemy_base.hp) * 5.0
    score += (base.resources - enemy_base.resources) * 2.0
    damage_dealt = (BASE_HP - enemy_base.hp)
    score += damage_dealt * 30

    if enemy_base.hp <= 0: score += 1000000
    if base.hp <= 0: score -= 500000
    return score


def log_to_csv(round_id, winner, r_gene, b_gene, duration):
    file_exists = os.path.isfile(CSV_FILE)
    with open(CSV_FILE, mode='a', newline='') as f:
        writer = csv.writer(f)
        if not file_exists:
            writer.writerow(['Round', 'Winner', 'Red_Gene', 'Blue_Gene', 'Duration'])
        writer.writerow([round_id, winner, str(r_gene), str(b_gene), f"{duration:.2f}"])


def mutate(gene):
    new = list(gene)
    idx = random.randint(0, 4)
    new[idx] = max(0.1, min(0.9, new[idx] + random.uniform(-0.1, 0.1)))
    idx_trait = random.randint(5, 7)
    new[idx_trait] = max(0.0, min(1.0, new[idx_trait] + random.uniform(-0.15, 0.15)))
    return new


def run_ants_ai(my_base, enemy_base, foods, strongholds, walls, enemies):
    aggression = my_base.gene[5]
    wanderlust = my_base.gene[6]
    cohesion_factor = my_base.gene[7]

    my_army = [a for a in my_base.ants if a.type != 'WORKER']

    # --- 🔥 全局威脅感知 (Global Awareness) ---
    threats_near_base = []
    base_danger_zone = 400 * SCALE
    for e in enemies:
        if math.hypot(e.x - my_base.x, e.y - my_base.y) < base_danger_zone:
            threats_near_base.append(e)

    # 1. 計算兵力優勢 (用於偵察兵強攻)
    enemy_combatants = sum(1 for e in enemies if e.type != 'WORKER')
    has_swarm_advantage = len(my_army) > max(3, enemy_combatants * 1.5)

    # 2. 找出敵方搬運工 (用於工蟻阻斷)
    enemy_carriers = [e for e in enemies if e.carrying_type is not None]

    # 3. 預計算據點擁擠度 (用於工蟻資源分配)
    stronghold_occupancy = {s: 0 for s in strongholds}
    for a in my_base.ants:
        if a.type == 'WORKER' and not a.carrying_type and a.mission_target:
            for s in strongholds:
                # 如果工蟻的任務目標坐標與據點一致，且距離較近，視為正在開採
                if a.mission_target == (s.x, s.y) and math.hypot(a.x - s.x, a.y - s.y) < 200 * SCALE:
                    stronghold_occupancy[s] += 1
                    break

    for ant in my_base.ants:
        # 🔥 更新冷卻 (使用 entities 新增的方法)
        if hasattr(ant, 'update_cooldown'):
            ant.update_cooldown()
        elif ant.attack_timer > 0:
            ant.attack_timer -= 1

        # 1. 資源回城
        if ant.carrying_type:
            ant.move_and_slide(my_base.x, my_base.y, walls, [], 0)
            if math.hypot(ant.x - my_base.x, ant.y - my_base.y) < ant.size + my_base.radius + 5:
                val = 0
                if ant.carrying_type == 'FOOD':
                    val = 15
                elif ant.carrying_type == 'ORB':
                    val = 2
                elif ant.carrying_type == 'STOLEN':
                    val = 1
                my_base.resources += val
                ant.carrying_type = None
            continue

        # 🔥 0. 偵察兵邏輯
        if ant.type == 'SCOUT' and not ant.carrying_type:
            dist_to_e_base = math.hypot(ant.x - enemy_base.x, ant.y - enemy_base.y)
            attack_range_base = ant.size + enemy_base.radius + ATTACK_REACH

            # A. 攻城 (最優先，防止卡住)
            if dist_to_e_base < attack_range_base:
                if ant.attack_timer == 0:
                    enemy_base.hp -= ant.atk
                    ant.attack_timer = ATTACK_COOLDOWN
                continue  # 正在攻擊，停止移動

            # B. 偷錢
            steal_range = ant.size + enemy_base.radius + 5
            if dist_to_e_base < steal_range:
                if enemy_base.resources >= SCOUT_STEAL_ENEMY_LOSS:
                    enemy_base.resources -= SCOUT_STEAL_ENEMY_LOSS
                    ant.carrying_type = 'STOLEN'
                    ant.mission_state = 'IDLE'
                    continue

            # C. 刺殺模式 (High Value Target)
            closest_prey = None;
            min_prey_dist = 9999
            for e in enemies:
                # 專殺工蟻和醫療兵
                if e.type in ['WORKER', 'MEDIC']:
                    d = math.hypot(ant.x - e.x, ant.y - e.y)
                    if d < VISION_RADIUS * 1.5 and d < min_prey_dist:
                        if ant.has_line_of_sight(e, walls): min_prey_dist = d; closest_prey = e

            if closest_prey:
                if ant.can_attack(closest_prey, min_prey_dist, walls, 0):
                    ant.perform_attack(closest_prey, ATTACK_COOLDOWN)
                else:
                    # 追擊
                    ant.move_and_slide(closest_prey.x, closest_prey.y, walls, [], 0)
                continue

            # D. 強攻或包抄
            if has_swarm_advantage:
                # 優勢大，直接衝
                ant.move_and_slide(enemy_base.x, enemy_base.y, walls, my_army, cohesion_factor)
            else:
                # 劣勢或均勢，走側翼
                if ant.mission_state == 'IDLE':
                    flank_y = 50 if random.random() < 0.5 else HEIGHT - 50
                    ant.mission_target = (enemy_base.x, flank_y)
                    ant.mission_state = 'FLANK'

                if ant.mission_target:
                    ant.move_and_slide(ant.mission_target[0], ant.mission_target[1], walls, [], 0)
                    if math.hypot(ant.x - ant.mission_target[0], ant.y - ant.mission_target[1]) < 150 * SCALE:
                        ant.mission_target = (enemy_base.x, enemy_base.y)  # 轉向基地
            continue

        # --- WORKER (工蟻) ---
        if ant.type == 'WORKER':
            closest_threat = None
            min_threat_dist = 9999
            threat_vision = VISION_RADIUS * 1.5

            for e in enemies:
                if e.type == 'WORKER': continue
                d = math.hypot(ant.x - e.x, ant.y - e.y)
                if d < threat_vision and d < min_threat_dist:
                    min_threat_dist = d;
                    closest_threat = e

            # 1. 逃跑
            should_flee = False
            if closest_threat:
                bodyguard_count = 0
                protection_radius = 200 * SCALE
                for ally in my_army:
                    if math.hypot(ant.x - ally.x, ant.y - ally.y) < protection_radius:
                        bodyguard_count += 1
                if bodyguard_count < 1 or min_threat_dist < 50 * SCALE:
                    should_flee = True

            if should_flee and closest_threat:
                dx = ant.x - closest_threat.x;
                dy = ant.y - closest_threat.y
                dist = math.hypot(dx, dy)
                if dist > 0:
                    ant.move_and_slide(ant.x + dx / dist * 100, ant.y + dy / dist * 100, walls, [], 0)
                continue

            # 🔥 2. [新增] 阻斷 (Harassment)
            closest_carrier = None;
            min_carry_dist = 9999
            for e in enemy_carriers:
                d = math.hypot(ant.x - e.x, ant.y - e.y)
                if d < VISION_RADIUS * 1.2 and d < min_carry_dist:
                    if ant.has_line_of_sight(e, walls): min_carry_dist = d; closest_carrier = e

            if closest_carrier:
                if ant.can_attack(closest_carrier, min_carry_dist, walls, 0):
                    ant.perform_attack(closest_carrier, ATTACK_COOLDOWN)
                else:
                    ant.move_and_slide(closest_carrier.x, closest_carrier.y, walls, [], 0)
                continue

                # 🔥 3. [新增] 採集 (公式: 2 + (n-1)*0.5)
            target = None;
            min_cost = 999999
            SEARCH_RADIUS = 300 * SCALE

            # A. 一次性食物
            for f in foods:
                d = math.hypot(ant.x - f.x, ant.y - f.y)
                cost = d * 0.6  # 距離優惠
                if d < SEARCH_RADIUS * 2 and cost < min_cost: min_cost = cost; target = f

            # B. 據點
            for s in strongholds:
                d = math.hypot(ant.x - s.x, ant.y - s.y)
                n = stronghold_occupancy.get(s, 0)
                # 公式轉化
                penalty_factor = 1.0 + ((2 + (n - 1) * 0.5) - 2) * 0.5 if n > 0 else 1.0
                cost = d * penalty_factor
                if cost < min_cost: min_cost = cost; target = s

            if target:
                ant.move_and_slide(target.x, target.y, walls, [], 0)

                # 更新佔用計數
                if isinstance(target, Stronghold) and ant.mission_target != (target.x, target.y):
                    stronghold_occupancy[target] += 1
                    ant.mission_target = (target.x, target.y)

                if isinstance(target, Food) and math.hypot(ant.x - target.x, ant.y - target.y) < 10 + ant.size:
                    target.value = 0;
                    ant.carrying_type = 'FOOD';
                    if target in foods: foods.remove(target)
                    my_base.add_food_signal(target.x, target.y)
                elif isinstance(target, Stronghold) and math.hypot(ant.x - target.x,
                                                                   ant.y - target.y) < target.radius + ant.size:
                    ant.carrying_type = 'ORB'
            else:
                rand_range = 300
                ant.move_and_slide(my_base.x + random.randint(-rand_range, rand_range),
                                   my_base.y + random.randint(-rand_range, rand_range), walls, [], 0)
            continue

        # --- 戰鬥單位 ---
        # 1. 攻城優先
        dist_to_base = math.hypot(ant.x - enemy_base.x, ant.y - enemy_base.y)
        attack_range_base = ant.size + enemy_base.radius + ATTACK_REACH
        if dist_to_base < attack_range_base:
            if ant.attack_timer == 0:
                dmg = ant.atk
                if ant.type == 'TANK':
                    dmg *= TANK_BASE_DMG_MULT
                elif ant.type == 'SOLDIER':
                    dmg *= SOLDIER_BASE_DMG_MULT
                enemy_base.hp -= dmg
                ant.attack_timer = ATTACK_COOLDOWN
                my_base.add_enemy_signal(enemy_base.x, enemy_base.y)
            continue

        # 2. 遭遇戰
        closest_e = None;
        min_e_dist = 9999
        vision = VISION_RADIUS
        if ant.type == 'SCOUT': vision = SCOUT_VISION

        for e in enemies:
            d = math.hypot(ant.x - e.x, ant.y - e.y)
            if d < vision and d < min_e_dist: min_e_dist = d; closest_e = e

        # 🔥 防穿牆檢查
        if closest_e and not ant.has_line_of_sight(closest_e, walls):
            closest_e = None

        if closest_e:
            my_base.add_enemy_signal(closest_e.x, closest_e.y)

            # 偵察兵智慧邏輯
            if ant.type == 'SCOUT' and closest_e.type != 'WORKER':
                is_suicide_mission = (hasattr(ant, 'mission_state') and ant.mission_state == 'ATTACK')
                allies_nearby = 0
                for ally in my_army:
                    if math.hypot(ant.x - ally.x, ant.y - ally.y) < VISION_RADIUS:
                        allies_nearby += 1

                if is_suicide_mission:
                    pass
                elif allies_nearby > 0:
                    pass
                else:
                    dx = ant.x - closest_e.x;
                    dy = ant.y - closest_e.y
                    margin = 80 * SCALE
                    if ant.x < margin:
                        dx += 200
                    elif ant.x > WIDTH - margin:
                        dx -= 200
                    if ant.y < margin:
                        dy += 200
                    elif ant.y > HEIGHT - margin:
                        dy -= 200
                    dist = math.hypot(dx, dy)
                    if dist > 0:
                        ant.move_and_slide(ant.x + dx / dist * 100, ant.y + dy / dist * 100, walls, [], 0)
                    continue

            # 🔥 攻擊判定 (防穿牆)
            if ant.can_attack(closest_e, min_e_dist, walls, 0):
                if ant.perform_attack(closest_e, ATTACK_COOLDOWN):
                    if closest_e.hp <= 0: my_base.resources += KILL_REWARD_NORMAL
            else:
                ant.move_and_slide(closest_e.x, closest_e.y, walls, my_army, cohesion_factor * 0.3)
            continue

        # 3. 醫療兵
        if ant.type == 'MEDIC':
            closest_hurt = None;
            min_h_dist = 9999
            for f in my_base.ants:
                if f is ant or f.hp >= f.max_hp: continue
                d = math.hypot(ant.x - f.x, ant.y - f.y)
                if d < vision and d < min_h_dist: min_h_dist = d; closest_hurt = f
            if closest_hurt:
                if min_h_dist < MEDIC_RANGE:
                    if ant.attack_timer == 0:
                        closest_hurt.hp = min(closest_hurt.max_hp, closest_hurt.hp + MEDIC_HEAL)
                        ant.attack_timer = MEDIC_COOLDOWN
                else:
                    ant.move_and_slide(closest_hurt.x, closest_hurt.y, walls, my_army, cohesion_factor)
                continue

        # --- 宏觀移動 (任務狀態機 + 危機感) ---
        if not hasattr(ant, 'mission_state'):
            ant.mission_state = 'IDLE'
            ant.mission_timer = 0
            ant.mission_target = (my_base.x, my_base.y)

        if ant.mission_state == 'ATTACK':
            if dist_to_base < 100 * SCALE:
                ant.mission_state = 'IDLE'
        else:
            ant.mission_timer -= 1

        if ant.mission_timer <= 0 and ant.mission_state != 'ATTACK':
            # --- 危機感計算 ---
            threats_near_base = []
            base_danger_zone = 400 * SCALE
            for e in enemies:
                if math.hypot(e.x - my_base.x, e.y - my_base.y) < base_danger_zone:
                    threats_near_base.append(e)

            pressure = len(threats_near_base) * 0.15
            effective_aggression = aggression - pressure

            if random.random() < effective_aggression:
                # === 進攻 ===
                ant.mission_state = 'ATTACK'
                offset = int(300 * wanderlust)
                ant.mission_target = (
                    enemy_base.x + random.randint(-offset, offset),
                    enemy_base.y + random.randint(-offset, offset)
                )
                if ant.type == 'TANK':
                    target_sh = None;
                    min_sh_dist = 9999
                    for sh in strongholds:
                        if sh.owner != my_base.team:
                            d = math.hypot(ant.x - sh.x, ant.y - sh.y)
                            if d < min_sh_dist: min_sh_dist = d; target_sh = sh
                    if target_sh: ant.mission_target = (target_sh.x, target_sh.y)
                ant.mission_timer = 5000
            else:
                # === 防守 ===
                ant.mission_state = 'DEFEND'
                if threats_near_base:
                    target = random.choice(threats_near_base)
                    ant.mission_target = (target.x, target.y)
                    ant.mission_timer = 60
                else:
                    patrol_r = 300 * SCALE
                    angle = random.uniform(0, 6.28)
                    r = random.uniform(50, patrol_r)
                    ant.mission_target = (
                        my_base.x + math.cos(angle) * r,
                        my_base.y + math.sin(angle) * r
                    )
                    ant.mission_timer = random.randint(200, 600)

        ant.move_and_slide(ant.mission_target[0], ant.mission_target[1], walls, my_army, cohesion_factor)


def main():
    pygame.init()
    print("===================================")
    print("1. 👁️ 觀看 | 2. 🚀 極速")
    mode = input("Select: ").strip()
    SHOW_GUI = (mode != '2')

    if SHOW_GUI:
        screen = pygame.display.set_mode((WIN_WIDTH, WIN_HEIGHT))
        game_surface = pygame.Surface((WIDTH, HEIGHT))
        pygame.display.set_caption("RTS Evolution - SCALED FINAL")
    else:
        screen = pygame.display.set_mode((1, 1), flags=pygame.HIDDEN)
        game_surface = None

    clock = pygame.time.Clock()
    cur_r, cur_b = load_latest_gene()

    rid = 1
    if os.path.exists(CSV_FILE):
        try:
            with open(CSV_FILE, 'r') as f:
                lines = list(csv.reader(f))
                if len(lines) > 1:
                    rid = int(lines[-1][0]) + 1
        except:
            pass

    try:
        while True:
            r_base, b_base, walls, foods, strongholds = reset_game_environment('RANDOM', cur_r, cur_b)
            start = time.time()
            running = True
            winner = None

            while running:
                if SHOW_GUI: clock.tick(FPS)
                for e in pygame.event.get():
                    if e.type == pygame.QUIT: pygame.quit(); return
                    if e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE: pygame.quit(); return

                r_base.update()
                b_base.update()
                r_base.spawn_logic()
                b_base.spawn_logic()
                for s in strongholds: s.update(r_base.ants, b_base.ants, r_base, b_base)

                run_ants_ai(r_base, b_base, foods, strongholds, walls, b_base.ants)
                run_ants_ai(b_base, r_base, foods, strongholds, walls, r_base.ants)

                r_base.ants = [a for a in r_base.ants if a.hp > 0]
                b_base.ants = [a for a in b_base.ants if a.hp > 0]

                if r_base.hp <= 0:
                    winner = 'BLUE';
                    running = False
                elif b_base.hp <= 0:
                    winner = 'RED';
                    running = False

                if running and (time.time() - start > 180):
                    r_score = calculate_score(r_base, b_base)
                    b_score = calculate_score(b_base, r_base)
                    print(f"⏰ Time Up! R:{int(r_score)} vs B:{int(b_score)}")
                    if r_score > b_score * 1.1:
                        winner = 'RED'
                    elif b_score > r_score * 1.1:
                        winner = 'BLUE'
                    else:
                        winner = 'DRAW'
                    running = False

                if SHOW_GUI:
                    game_surface.fill(BLACK)
                    for w in walls: w.draw(game_surface)
                    for s in strongholds: s.draw(game_surface)
                    for f in foods: f.draw(game_surface)
                    r_base.draw(game_surface)
                    b_base.draw(game_surface)
                    for a in r_base.ants:
                        a.draw(game_surface)
                        if hasattr(a, 'mission_state') and a.mission_state == 'ATTACK':
                            end_pos = (int(a.mission_target[0]), int(a.mission_target[1]))
                            line_col = (100, 50, 50) if a.team == 'RED' else (50, 50, 100)
                            pygame.draw.line(game_surface, line_col, (int(a.x), int(a.y)), end_pos, 1)

                    for a in b_base.ants:
                        a.draw(game_surface)
                        if hasattr(a, 'mission_state') and a.mission_state == 'ATTACK':
                            end_pos = (int(a.mission_target[0]), int(a.mission_target[1]))
                            line_col = (50, 50, 100)
                            pygame.draw.line(game_surface, line_col, (int(a.x), int(a.y)), end_pos, 1)

                    scaled_surface = pygame.transform.scale(game_surface, (WIN_WIDTH, WIN_HEIGHT))
                    screen.blit(scaled_surface, (0, 0))
                    pygame.display.flip()

            duration = time.time() - start
            if rid % LOG_INTERVAL == 0: log_to_csv(rid, winner, cur_r, cur_b, duration)
            print(f"Round {rid}: {winner} (Time: {duration:.2f}s)")

            if winner == 'RED':
                best = cur_r
            elif winner == 'BLUE':
                best = cur_b
            else:
                best = cur_r

            cur_r = mutate(best)
            cur_b = mutate(best)
            rid += 1

    except KeyboardInterrupt:
        print("\n🛑 用戶手動停止 (KeyboardInterrupt)")
        pygame.quit()
        sys.exit()


if __name__ == "__main__":
    main()