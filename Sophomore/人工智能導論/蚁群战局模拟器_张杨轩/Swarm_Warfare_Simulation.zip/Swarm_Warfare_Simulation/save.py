import pygame
import csv
import os
import time
import math
import random
import sys  # 🔥 1. 新增這行：為了能強制退出程式
from settings import *
from entities import Base, Ant, Food, Wall, Stronghold, reset_game_environment

DATA_DIR = 'data'
CSV_FILE = os.path.join(DATA_DIR, 'training_results.csv')
if not os.path.exists(DATA_DIR): os.makedirs(DATA_DIR)

# 🔥🔥🔥 將常數移到最外層，確保所有函數都能訪問，解決 NameError 🔥🔥🔥
ATTACK_REACH = 10 * SCALE
ATTACK_COOLDOWN = 1
MEDIC_COOLDOWN = 10


def load_latest_gene():
    default_gene = [0.5, 0.4, 0.2, 0.2, 0.2, 0.5, 0.5, 0.5]
    if not os.path.exists(CSV_FILE): return default_gene, default_gene
    try:
        with open(CSV_FILE, 'r') as f:
            lines = list(csv.reader(f))
            if len(lines) < 2: return default_gene, default_gene
            last = lines[-1]
            winner = last[1]
            try:
                r = eval(last[2])
                b = eval(last[3])

                def fix(g):
                    if not isinstance(g, list): g = default_gene
                    if len(g) < 8: g += default_gene[len(g):]
                    return g[:8]

                if winner == 'RED':
                    return fix(r), fix(b)
                else:
                    return fix(b), fix(b)
            except:
                return default_gene, default_gene
    except:
        return default_gene, default_gene


def calculate_score(base, enemy_base):
    # 零和博弈評分
    score = (base.hp - enemy_base.hp) * 5.0
    score += (base.resources - enemy_base.resources) * 2.0
    damage_dealt = (BASE_HP - enemy_base.hp)
    score += damage_dealt * 30

    if enemy_base.hp <= 0: score += 1000000
    if base.hp <= 0: score -= 500000
    return score


def log_to_csv(round_id, winner, r_gene, b_gene, duration):
    file_exists = os.path.isfile(CSV_FILE)
    with open(CSV_FILE, mode='a', newline='') as f:
        writer = csv.writer(f)
        if not file_exists:
            writer.writerow(['Round', 'Winner', 'Red_Gene', 'Blue_Gene', 'Duration'])
        writer.writerow([round_id, winner, str(r_gene), str(b_gene), f"{duration:.2f}"])


def mutate(gene):
    new = list(gene)
    idx = random.randint(0, 4)
    new[idx] = max(0.1, min(0.9, new[idx] + random.uniform(-0.1, 0.1)))
    idx_trait = random.randint(5, 7)
    new[idx_trait] = max(0.0, min(1.0, new[idx_trait] + random.uniform(-0.15, 0.15)))
    return new


def run_ants_ai(my_base, enemy_base, foods, strongholds, walls, enemies):
    aggression = my_base.gene[5]
    wanderlust = my_base.gene[6]
    cohesion_factor = my_base.gene[7]

    my_army = [a for a in my_base.ants if a.type != 'WORKER']

    # 🔥 [新增] 戰術分析：計算雙方兵力差，用於決定偵察兵是否強沖 (Swarm Rush)
    enemy_combatants = sum(1 for e in enemies if e.type != 'WORKER')
    has_swarm_advantage = len(my_army) > max(3, enemy_combatants * 1.5)

    # 🔥 [新增] 預計算：找出敵方正在搬運的工蟻 (用於工蟻阻斷)
    enemy_carriers = [e for e in enemies if e.carrying_type is not None]

    # 🔥 [新增] 預計算：無限資源點的擁擠程度 (用於工蟻資源分配公式)
    stronghold_occupancy = {s: 0 for s in strongholds}
    for a in my_base.ants:
        if a.type == 'WORKER' and not a.carrying_type:
            # 簡單判斷：如果工蟻距離某個據點很近，就算它在挖
            for s in strongholds:
                if math.hypot(a.x - s.x, a.y - s.y) < 100 * SCALE:
                    stronghold_occupancy[s] += 1
                    break

    for ant in my_base.ants:
        # 🔥 [新增] 必須調用 update_cooldown，否則攻擊頻率會錯亂
        if hasattr(ant, 'update_cooldown'):
            ant.update_cooldown()
        elif ant.attack_timer > 0:
            ant.attack_timer -= 1  # 兼容舊代碼

        # 1. 資源回城
        if ant.carrying_type:
            ant.move_and_slide(my_base.x, my_base.y, walls, [], 0)
            if math.hypot(ant.x - my_base.x, ant.y - my_base.y) < ant.size + my_base.radius + 5:
                val = 0
                if ant.carrying_type == 'FOOD':
                    val = 15
                elif ant.carrying_type == 'ORB':
                    val = 2
                elif ant.carrying_type == 'STOLEN':
                    val = 1
                my_base.resources += val
                ant.carrying_type = None
            continue

        # 🔥 0. 偵察兵 (SCOUT) 邏輯：偷竊 + [新增] 刺殺/包抄/強沖
        if ant.type == 'SCOUT' and not ant.carrying_type:
            dist_to_e_base = math.hypot(ant.x - enemy_base.x, ant.y - enemy_base.y)

            # A. 偷錢優先
            if dist_to_e_base < ant.size + enemy_base.radius + 5 and enemy_base.resources >= SCOUT_STEAL_ENEMY_LOSS:
                enemy_base.resources -= SCOUT_STEAL_ENEMY_LOSS
                ant.carrying_type = 'STOLEN'
                ant.mission_state = 'IDLE'
                continue

            # B. [新增] 刺殺模式：尋找視野內的高價值目標 (工蟻/醫療兵)
            # 無視坦克和士兵，專殺脆皮
            closest_prey = None
            min_prey_dist = 9999

            # 使用 entities.py 的視線檢測
            has_los_func = getattr(ant, 'has_line_of_sight', lambda t, w: True)

            for e in enemies:
                if e.type in ['WORKER', 'MEDIC']:
                    d = math.hypot(ant.x - e.x, ant.y - e.y)
                    # 偵察兵視野大，可以看遠一點找獵物
                    if d < VISION_RADIUS * 1.5 and d < min_prey_dist:
                        if has_los_func(e, walls):
                            min_prey_dist = d
                            closest_prey = e

            if closest_prey:
                can_attack_func = getattr(ant, 'can_attack', None)
                perform_attack_func = getattr(ant, 'perform_attack', None)

                # 如果能打到，直接攻擊
                if can_attack_func and perform_attack_func:
                    if can_attack_func(closest_prey, min_prey_dist, walls, 0):
                        if perform_attack_func(closest_prey, ATTACK_COOLDOWN):
                            if closest_prey.hp <= 0: my_base.resources += KILL_REWARD_CARRIER
                    else:
                        # 全速追擊 (不考慮隊形，就是要換命)
                        ant.move_and_slide(closest_prey.x, closest_prey.y, walls, [], 0)
                else:
                    # 兼容舊代碼的直接攻擊邏輯
                    combat_range = ant.size + closest_prey.size + ATTACK_REACH
                    if min_prey_dist < combat_range:
                        if ant.attack_timer == 0:
                            closest_prey.hp -= ant.atk
                            ant.attack_timer = ATTACK_COOLDOWN
                    else:
                        ant.move_and_slide(closest_prey.x, closest_prey.y, walls, [], 0)
                continue  # 🔥 專注刺殺，不走後面的邏輯

            # C. [新增] 強攻模式 (Swarm Rush)
            # 如果兵力優勢大，或者是對方基地沒人，直接衝
            defenders = sum(1 for e in enemies if math.hypot(e.x - enemy_base.x, e.y - enemy_base.y) < 300 * SCALE)
            if has_swarm_advantage or defenders == 0:
                ant.move_and_slide(enemy_base.x, enemy_base.y, walls, my_army, cohesion_factor)
                continue

            # D. [新增] 包抄模式 (Flanking)
            # 如果沒事做，不要傻傻走直線，嘗試走上下兩路包抄
            if ant.mission_state == 'IDLE':
                flank_y = 50 if random.random() < 0.5 else HEIGHT - 50
                ant.mission_target = (enemy_base.x, flank_y)
                ant.mission_state = 'FLANK'

            if ant.mission_target:
                ant.move_and_slide(ant.mission_target[0], ant.mission_target[1], walls, [], 0)
                # 接近包抄點後轉向基地
                if math.hypot(ant.x - ant.mission_target[0], ant.y - ant.mission_target[1]) < 200 * SCALE:
                    ant.mission_target = (enemy_base.x, enemy_base.y)
            continue

        # --- WORKER (工蟻) ---
        if ant.type == 'WORKER':
            # 1. 逃跑 (使用新增的 get_closest_enemy)
            get_enemy_func = getattr(ant, 'get_closest_enemy', None)
            if get_enemy_func:
                closest_threat, min_threat_dist = get_enemy_func(enemies, VISION_RADIUS)
                if closest_threat and min_threat_dist < 100 * SCALE:
                    # 簡單的反向逃跑
                    dx = ant.x - closest_threat.x
                    dy = ant.y - closest_threat.y
                    ant.move_and_slide(ant.x + dx, ant.y + dy, walls, [], 0)
                    continue

            # 🔥 2. [新增] 阻斷邏輯 (Harassment)
            # 如果看到敵方搬運工，優先去咬他
            closest_carrier = None;
            min_carry_dist = 9999
            has_los_func = getattr(ant, 'has_line_of_sight', lambda t, w: True)

            for e in enemy_carriers:
                d = math.hypot(ant.x - e.x, ant.y - e.y)
                # 視野稍微大一點去尋找機會
                if d < VISION_RADIUS * 1.2 and d < min_carry_dist:
                    if has_los_func(e, walls):
                        min_carry_dist = d;
                        closest_carrier = e

            if closest_carrier:
                can_attack_func = getattr(ant, 'can_attack', None)
                perform_attack_func = getattr(ant, 'perform_attack', None)

                if can_attack_func and perform_attack_func:
                    if can_attack_func(closest_carrier, min_carry_dist, walls, 0):
                        if perform_attack_func(closest_carrier, ATTACK_COOLDOWN):
                            if closest_carrier.hp <= 0: my_base.resources += KILL_REWARD_CARRIER
                    else:
                        ant.move_and_slide(closest_carrier.x, closest_carrier.y, walls, [], 0)
                continue  # 🔥 執行了阻斷，就不去採集了

            # 🔥 3. [修改] 採集邏輯 (應用公式：2 + (n-1)*0.5)
            target = None;
            min_dist = 999999

            # A. 評估一次性食物 (距離優先)
            for f in foods:
                d = math.hypot(ant.x - f.x, ant.y - f.y)
                cost = d * 0.6  # 給予距離優惠 (0.6倍)，鼓勵優先撿
                if d < 500 * SCALE and cost < min_dist: min_dist = cost; target = f

            # B. 評估無限資源點 (應用擁擠懲罰公式)
            for s in strongholds:
                d = math.hypot(ant.x - s.x, ant.y - s.y)
                n = stronghold_occupancy.get(s, 0)

                # 你的公式：2 + (n-1)*0.5
                # 我們把這個係數乘到距離上，讓擁擠的點看起來"非常遠"
                congestion_factor = 2.0
                if n > 0:
                    congestion_factor += (n - 1) * 0.5

                # 轉化為距離權重：基礎倍率 1.0 (對應公式2)，每多一人增加 25% 距離感
                cost = d * (1.0 + (congestion_factor - 2.0) * 0.5)

                if cost < min_dist: min_dist = cost; target = s

            if target:
                ant.move_and_slide(target.x, target.y, walls, [], 0)
                if isinstance(target, Food) and math.hypot(ant.x - target.x, ant.y - target.y) < 10 + ant.size:
                    target.value = 0;
                    ant.carrying_type = 'FOOD';
                    if target in foods: foods.remove(target)
                    my_base.add_food_signal(target.x, target.y)
                elif isinstance(target, Stronghold) and math.hypot(ant.x - target.x,
                                                                   ant.y - target.y) < target.radius + ant.size:
                    ant.carrying_type = 'ORB'
            else:
                # 沒資源了，隨機走
                ant.move_and_slide(ant.x + random.randint(-100, 100), ant.y + random.randint(-100, 100), walls, [], 0)
            continue

        # --- 戰鬥單位 ---
        # 1. 攻城優先
        dist_to_base = math.hypot(ant.x - enemy_base.x, ant.y - enemy_base.y)
        attack_range_base = ant.size + enemy_base.radius + ATTACK_REACH
        if dist_to_base < attack_range_base:
            if ant.attack_timer == 0:
                dmg = ant.atk
                if ant.type == 'TANK':
                    dmg *= TANK_BASE_DMG_MULT
                elif ant.type == 'SOLDIER':
                    dmg *= SOLDIER_BASE_DMG_MULT
                enemy_base.hp -= dmg
                ant.attack_timer = ATTACK_COOLDOWN
                my_base.add_enemy_signal(enemy_base.x, enemy_base.y)
            continue

        # 2. 遭遇戰
        # 🔥 使用 entities.py 的 get_closest_enemy 尋找最近敵人
        get_enemy_func = getattr(ant, 'get_closest_enemy', None)
        can_attack_func = getattr(ant, 'can_attack', None)
        perform_attack_func = getattr(ant, 'perform_attack', None)
        has_los_func = getattr(ant, 'has_line_of_sight', lambda t, w: True)

        closest_e = None
        if get_enemy_func:
            closest_e, min_e_dist = get_enemy_func(enemies, VISION_RADIUS)
            # 🔥 防穿牆：如果被牆擋住，視為沒看到
            if closest_e and not has_los_func(closest_e, walls):
                closest_e = None
        else:
            # Fallback
            min_e_dist = 9999
            for e in enemies:
                d = math.hypot(ant.x - e.x, ant.y - e.y)
                if d < VISION_RADIUS and d < min_e_dist: min_e_dist = d; closest_e = e

        if closest_e:
            my_base.add_enemy_signal(closest_e.x, closest_e.y)

            # 🔥 [修改] 使用 can_attack (含視線) 進行攻擊判定
            attacked = False
            if can_attack_func and perform_attack_func:
                if can_attack_func(closest_e, min_e_dist, walls, 0):
                    if perform_attack_func(closest_e, ATTACK_COOLDOWN):
                        if closest_e.hp <= 0: my_base.resources += KILL_REWARD_NORMAL
                    attacked = True
            elif min_e_dist < ant.size + closest_e.size + ATTACK_REACH:
                if ant.attack_timer == 0:
                    closest_e.hp -= ant.atk
                    ant.attack_timer = ATTACK_COOLDOWN
                attacked = True

            if not attacked:
                ant.move_and_slide(closest_e.x, closest_e.y, walls, my_army, cohesion_factor * 0.3)
            continue

        # 3. 醫療兵
        if ant.type == 'MEDIC':
            closest_hurt = None;
            min_h_dist = 9999
            for f in my_base.ants:
                if f is ant or f.hp >= f.max_hp: continue
                d = math.hypot(ant.x - f.x, ant.y - f.y)
                if d < VISION_RADIUS and d < min_h_dist: min_h_dist = d; closest_hurt = f  # 修正 vision
            if closest_hurt:
                if min_h_dist < MEDIC_RANGE:
                    if ant.attack_timer == 0:
                        closest_hurt.hp = min(closest_hurt.max_hp, closest_hurt.hp + MEDIC_HEAL)
                        ant.attack_timer = MEDIC_COOLDOWN
                else:
                    ant.move_and_slide(closest_hurt.x, closest_hurt.y, walls, my_army, cohesion_factor)
                continue

        # --- 宏觀移動 (任務狀態機 + 危機感) ---
        if not hasattr(ant, 'mission_state'):
            ant.mission_state = 'IDLE'
            ant.mission_timer = 0
            ant.mission_target = (my_base.x, my_base.y)

        if ant.mission_state == 'ATTACK':
            if dist_to_base < 100 * SCALE:
                ant.mission_state = 'IDLE'
        else:
            ant.mission_timer -= 1

        if ant.mission_timer <= 0 and ant.mission_state != 'ATTACK':
            threats_near_base = []
            base_danger_zone = 400 * SCALE
            for e in enemies:
                if math.hypot(e.x - my_base.x, e.y - my_base.y) < base_danger_zone:
                    threats_near_base.append(e)

            pressure = len(threats_near_base) * 0.15
            effective_aggression = aggression - pressure

            if random.random() < effective_aggression:
                ant.mission_state = 'ATTACK'
                offset = int(300 * wanderlust)
                ant.mission_target = (
                    enemy_base.x + random.randint(-offset, offset),
                    enemy_base.y + random.randint(-offset, offset)
                )
                if ant.type == 'TANK':
                    target_sh = None;
                    min_sh_dist = 9999
                    for sh in strongholds:
                        if sh.owner != my_base.team:
                            d = math.hypot(ant.x - sh.x, ant.y - sh.y)
                            if d < min_sh_dist: min_sh_dist = d; target_sh = sh
                    if target_sh: ant.mission_target = (target_sh.x, target_sh.y)
                ant.mission_timer = 5000
            else:
                ant.mission_state = 'DEFEND'
                if threats_near_base:
                    target = random.choice(threats_near_base)
                    ant.mission_target = (target.x, target.y)
                    ant.mission_timer = 60
                else:
                    patrol_r = 300 * SCALE
                    angle = random.uniform(0, 6.28)
                    r = random.uniform(50, patrol_r)
                    ant.mission_target = (
                        my_base.x + math.cos(angle) * r,
                        my_base.y + math.sin(angle) * r
                    )
                    ant.mission_timer = random.randint(200, 600)

        ant.move_and_slide(ant.mission_target[0], ant.mission_target[1], walls, my_army, cohesion_factor)


def main():
    pygame.init()
    print("===================================")
    print("1. 👁️ 觀看 | 2. 🚀 極速")
    mode = input("Select: ").strip()
    SHOW_GUI = (mode != '2')

    if SHOW_GUI:
        screen = pygame.display.set_mode((WIN_WIDTH, WIN_HEIGHT))
        game_surface = pygame.Surface((WIDTH, HEIGHT))
        pygame.display.set_caption("RTS Evolution - SCALED FINAL")
    else:
        screen = pygame.display.set_mode((1, 1), flags=pygame.HIDDEN)
        game_surface = None

    clock = pygame.time.Clock()
    cur_r, cur_b = load_latest_gene()

    rid = 1
    if os.path.exists(CSV_FILE):
        try:
            with open(CSV_FILE, 'r') as f:
                lines = list(csv.reader(f))
                if len(lines) > 1:
                    rid = int(lines[-1][0]) + 1
        except:
            pass

    try:
        while True:
            r_base, b_base, walls, foods, strongholds = reset_game_environment('RANDOM', cur_r, cur_b)
            start = time.time()
            running = True
            winner = None

            while running:
                if SHOW_GUI: clock.tick(FPS)
                for e in pygame.event.get():
                    if e.type == pygame.QUIT: pygame.quit(); return
                    if e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE: pygame.quit(); return

                r_base.update()
                b_base.update()
                r_base.spawn_logic()
                b_base.spawn_logic()
                for s in strongholds: s.update(r_base.ants, b_base.ants, r_base, b_base)

                run_ants_ai(r_base, b_base, foods, strongholds, walls, b_base.ants)
                run_ants_ai(b_base, r_base, foods, strongholds, walls, r_base.ants)

                r_base.ants = [a for a in r_base.ants if a.hp > 0]
                b_base.ants = [a for a in b_base.ants if a.hp > 0]

                if r_base.hp <= 0:
                    winner = 'BLUE';
                    running = False
                elif b_base.hp <= 0:
                    winner = 'RED';
                    running = False

                if running and (time.time() - start > 180):
                    r_score = calculate_score(r_base, b_base)
                    b_score = calculate_score(b_base, r_base)
                    print(f"⏰ Time Up! R:{int(r_score)} vs B:{int(b_score)}")
                    if r_score > b_score * 1.1:
                        winner = 'RED'
                    elif b_score > r_score * 1.1:
                        winner = 'BLUE'
                    else:
                        winner = 'DRAW'
                    running = False

                if SHOW_GUI:
                    game_surface.fill(BLACK)
                    for w in walls: w.draw(game_surface)
                    for s in strongholds: s.draw(game_surface)
                    for f in foods: f.draw(game_surface)
                    r_base.draw(game_surface);
                    b_base.draw(game_surface)
                    for a in r_base.ants:
                        a.draw(game_surface)
                        if hasattr(a, 'mission_state') and a.mission_state == 'ATTACK':
                            end_pos = (int(a.mission_target[0]), int(a.mission_target[1]))
                            line_col = (100, 50, 50) if a.team == 'RED' else (50, 50, 100)
                            pygame.draw.line(game_surface, line_col, (int(a.x), int(a.y)), end_pos, 1)

                    for a in b_base.ants:
                        a.draw(game_surface)
                        if hasattr(a, 'mission_state') and a.mission_state == 'ATTACK':
                            end_pos = (int(a.mission_target[0]), int(a.mission_target[1]))
                            line_col = (50, 50, 100)
                            pygame.draw.line(game_surface, line_col, (int(a.x), int(a.y)), end_pos, 1)

                    scaled_surface = pygame.transform.scale(game_surface, (WIN_WIDTH, WIN_HEIGHT))
                    screen.blit(scaled_surface, (0, 0))
                    pygame.display.flip()

            duration = time.time() - start
            if rid % LOG_INTERVAL == 0: log_to_csv(rid, winner, cur_r, cur_b, duration)
            print(f"Round {rid}: {winner} (Time: {duration:.2f}s)")

            if winner == 'RED':
                best = cur_r
            elif winner == 'BLUE':
                best = cur_b
            else:
                best = cur_r

            cur_r = mutate(best)
            cur_b = mutate(best)
            rid += 1

    except KeyboardInterrupt:
        print("\n🛑 用戶手動停止 (KeyboardInterrupt)")
        pygame.quit()
        sys.exit()


if __name__ == "__main__":
    main()