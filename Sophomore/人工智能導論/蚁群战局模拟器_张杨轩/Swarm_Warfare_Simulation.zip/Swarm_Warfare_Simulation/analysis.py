import csv
import ast
import matplotlib.pyplot as plt
import os

DATA_FILE = os.path.join('data', 'training_results.csv')


def load_data():
    if not os.path.exists(DATA_FILE):
        print(f"❌ 找不到數據文件: {DATA_FILE}")
        return None

    rounds = []
    winners = []
    durations = []
    # 存儲獲勝者的基因，用來觀察進化趨勢
    winning_genes = []

    print("正在讀取數據...")
    with open(DATA_FILE, 'r') as f:
        reader = csv.reader(f)
        try:
            header = next(reader)  # 跳過標題
        except StopIteration:
            print("文件為空")
            return None

        for row in reader:
            if not row: continue
            try:
                rid = int(row[0])
                winner = row[1]
                r_gene = ast.literal_eval(row[2])
                b_gene = ast.literal_eval(row[3])
                duration = float(row[4])

                rounds.append(rid)
                winners.append(winner)
                durations.append(duration)

                # 我們只記錄獲勝者的基因，看看什麼樣的基因會留下來
                if winner == 'RED':
                    winning_genes.append(r_gene)
                elif winner == 'BLUE':
                    winning_genes.append(b_gene)
                else:
                    # 平局時，取雙方平均或隨機，這裡暫取紅方代表
                    winning_genes.append(r_gene)

            except Exception as e:
                print(f"跳過錯誤行: {row} -> {e}")
                continue

    return rounds, winners, durations, winning_genes


def plot_analysis(rounds, winners, durations, winning_genes):
    plt.style.use('bmh')  # 使用比較好看的樣式
    fig = plt.figure(figsize=(14, 10))
    fig.suptitle(f'RTS Evolution Analysis (Total Rounds: {len(rounds)})', fontsize=16)

    # 1. 勝率分布 (餅圖)
    ax1 = plt.subplot(2, 2, 1)
    red_wins = winners.count('RED')
    blue_wins = winners.count('BLUE')
    draws = winners.count('DRAW')
    ax1.pie([red_wins, blue_wins, draws], labels=['RED', 'BLUE', 'DRAW'],
            autopct='%1.1f%%', colors=['#ff6666', '#6666ff', '#999999'], startangle=90)
    ax1.set_title('Win Rate Distribution')

    # 2. 對局時長趨勢 (折線圖)
    ax2 = plt.subplot(2, 2, 2)
    # 計算移動平均線 (Moving Average) 讓趨勢更明顯
    window_size = 10
    if len(durations) >= window_size:
        moving_avg = [sum(durations[i:i + window_size]) / window_size for i in range(len(durations) - window_size + 1)]
        ax2.plot(rounds[window_size - 1:], moving_avg, color='orange', label=f'{window_size}-Round Moving Avg')
        ax2.scatter(rounds, durations, s=5, alpha=0.3, color='gray')  # 原始數據點
    else:
        ax2.plot(rounds, durations, color='orange')
    ax2.set_xlabel('Round')
    ax2.set_ylabel('Duration (Seconds)')
    ax2.set_title('Match Duration Trend')
    ax2.legend()

    # 3. 基因進化趨勢 (核心圖表)
    # 基因結構: [兵種概率, 士兵權重, 坦克權重, 醫療權重, 偵察權重, 攻擊性, 遊蕩性, 團結性]
    ax3 = plt.subplot(2, 1, 2)

    # 轉置矩陣以便繪圖
    genes_T = list(zip(*winning_genes))

    gene_labels = [
        'Soldier Prob', 'W_Soldier', 'W_Tank', 'W_Medic', 'W_Scout',
        'Aggression', 'Wanderlust', 'Cohesion'
    ]

    # 為了不讓圖表太亂，我們畫出趨勢線
    for i, gene_data in enumerate(genes_T):
        # 平滑處理
        if len(gene_data) >= window_size:
            smooth_data = [sum(gene_data[j:j + window_size]) / window_size for j in
                           range(len(gene_data) - window_size + 1)]
            ax3.plot(rounds[window_size - 1:], smooth_data, label=gene_labels[i])
        else:
            ax3.plot(rounds, gene_data, label=gene_labels[i])

    ax3.set_xlabel('Round')
    ax3.set_ylabel('Gene Value (0.0 - 1.0)')
    ax3.set_title('Winning Gene Evolution (Moving Average)')
    ax3.legend(loc='upper right', bbox_to_anchor=(1.12, 1))
    ax3.grid(True)

    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    data = load_data()
    if data:
        rounds, winners, durations, winning_genes = data
        if len(rounds) > 0:
            plot_analysis(rounds, winners, durations, winning_genes)
        else:
            print("數據不足，無法繪圖")