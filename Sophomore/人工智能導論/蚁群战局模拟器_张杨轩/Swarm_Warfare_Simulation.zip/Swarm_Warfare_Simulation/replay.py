import pygame
import csv
import os
import math
import random
from settings import *
from entities import Base, Ant, Food, Wall, Stronghold, reset_game_environment
from main import run_ants_ai, load_latest_gene

DATA_DIR = 'data'
CSV_FILE = os.path.join(DATA_DIR, 'training_results.csv')


def load_all_data():
    data = {}
    if not os.path.exists(CSV_FILE): return data
    with open(CSV_FILE, 'r') as f:
        reader = csv.reader(f)
        try:
            next(reader)
            for row in reader:
                if not row: continue
                rid = int(row[0])
                try:
                    r = eval(row[2])
                    b = eval(row[3])
                    data[rid] = {'r': r, 'b': b, 'w': row[1]}
                except:
                    pass
        except:
            pass
    return data


def play(r_gene, b_gene, map_mode='STANDARD'):
    pygame.init()
    screen = pygame.display.set_mode((WIN_WIDTH, WIN_HEIGHT))
    game_surface = pygame.Surface((WIDTH, HEIGHT))

    info = f"R[{len(r_gene)}] vs B[{len(b_gene)}]"
    pygame.display.set_caption(f"Replay - {info}")
    clock = pygame.time.Clock()

    r_base, b_base, walls, foods, strongholds = reset_game_environment(map_mode, r_gene, b_gene)

    running = True
    while running:
        clock.tick(60)
        for e in pygame.event.get():
            if e.type == pygame.QUIT: pygame.quit(); return
            if e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE: running = False

        r_base.update();
        b_base.update()
        r_base.spawn_logic();
        b_base.spawn_logic()
        for s in strongholds: s.update(r_base.ants, b_base.ants, r_base, b_base)

        run_ants_ai(r_base, b_base, foods, strongholds, walls, b_base.ants)
        run_ants_ai(b_base, r_base, foods, strongholds, walls, r_base.ants)

        r_base.ants = [a for a in r_base.ants if a.hp > 0]
        b_base.ants = [a for a in b_base.ants if a.hp > 0]

        game_surface.fill(BLACK)
        for w in walls: w.draw(game_surface)
        for s in strongholds: s.draw(game_surface)
        for f in foods: f.draw(game_surface)
        r_base.draw(game_surface);
        b_base.draw(game_surface)
        for a in r_base.ants: a.draw(game_surface)
        for a in b_base.ants: a.draw(game_surface)

        scaled = pygame.transform.scale(game_surface, (WIN_WIDTH, WIN_HEIGHT))
        screen.blit(scaled, (0, 0))
        pygame.display.flip()

        if r_base.hp <= 0 or b_base.hp <= 0: running = False


def main():
    while True:
        data = load_all_data()
        if not data: print("無數據"); return

        rounds = sorted(data.keys())
        print(f"\n📊 存檔局數: {rounds}")
        u = input("👉 輸入局數 (q退出): ")
        if u == 'q': break
        if not u.isdigit(): continue

        tid = int(u)
        if tid in data:
            rg, bg = data[tid]['r'], data[tid]['b']
        else:
            valid = [r for r in rounds if r < tid]
            start = valid[-1] if valid else 0
            rg, bg = [0.5]*8, [0.5]*8
            if start in data:
                rg, bg = data[start]['r'], data[start]['b']
            print(f"⚠️ 讀取最近存檔: {start}")

        mode = input("1:標準 2:隨機 : ")
        play(rg, bg, 'RANDOM' if mode == '2' else 'STANDARD')


if __name__ == "__main__":
    main()