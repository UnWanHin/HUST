import pygame
import math
import random
from settings import *


# ==========================================
# 🧱 牆壁實體 (Wall) - [完全保留]
# ==========================================
class Wall:
    def __init__(self, x, y, w, h):
        self.rect = pygame.Rect(x, y, w, h)

    def draw(self, surface):
        pygame.draw.rect(surface, (50, 50, 50), self.rect)
        pygame.draw.rect(surface, (100, 100, 100), self.rect, 1)


# ==========================================
# 🗺️ 迷宮生成器 (MazeGenerator) - [完全保留]
# ==========================================
class MazeGenerator:
    def __init__(self, cols, rows, erosion_rate):
        self.cols = cols
        self.rows = rows
        self.erosion_rate = erosion_rate
        # 初始化全為牆 (1)
        self.grid = [[1 for _ in range(cols)] for _ in range(rows)]

    def generate(self):
        # 從 (1,1) 開始挖掘
        self.carve(1, 1)
        # 移除死胡同以增加連通性
        self.remove_dead_ends()
        # 隨機侵蝕牆壁，製造開闊地
        self.erode()
        return self.grid

    def carve(self, cx, cy):
        self.grid[cy][cx] = 0
        # 隨機打亂四個方向
        directions = [(0, -2), (0, 2), (-2, 0), (2, 0)]
        random.shuffle(directions)
        for dx, dy in directions:
            nx, ny = cx + dx, cy + dy
            # 檢查邊界
            if 1 <= nx < self.cols - 1 and 1 <= ny < self.rows - 1:
                if self.grid[ny][nx] == 1:
                    # 打通中間的牆
                    self.grid[cy + dy // 2][cx + dx // 2] = 0
                    self.carve(nx, ny)

    def remove_dead_ends(self):
        # 遍歷尋找只有一個出口的格子
        for y in range(1, self.rows - 1):
            for x in range(1, self.cols - 1):
                if self.grid[y][x] == 0:
                    neighbors = sum([
                        self.grid[y - 1][x],
                        self.grid[y + 1][x],
                        self.grid[y][x - 1],
                        self.grid[y][x + 1]
                    ])
                    # 如果周圍有3個或更多牆壁，視為死胡同
                    if neighbors >= 3:
                        options = []
                        if y > 1: options.append((0, -1))
                        if y < self.rows - 2: options.append((0, 1))
                        if x > 1: options.append((-1, 0))
                        if x < self.cols - 2: options.append((1, 0))

                        if options:
                            dx, dy = random.choice(options)
                            if 0 < y + dy < self.rows and 0 < x + dx < self.cols:
                                self.grid[y + dy][x + dx] = 0

    def erode(self):
        # 隨機移除牆壁
        for y in range(1, self.rows - 1):
            for x in range(1, self.cols - 1):
                if self.grid[y][x] == 1:
                    if random.random() < self.erosion_rate:
                        self.grid[y][x] = 0


# ==========================================
# 🏰 據點 (Stronghold) - [完全保留]
# ==========================================
class Stronghold:
    def __init__(self, x, y):
        self.x, self.y = x, y
        self.radius = STRONGHOLD_RADIUS
        self.owner = None
        self.capture_val = 0
        self.timer = 0
        self.color_neutral = CYAN
        self.color_red = RED_COLOR
        self.color_blue = BLUE_COLOR

    def update(self, red_ants, blue_ants, red_base, blue_base):
        # 計算範圍內的兵力
        r_count = sum(1 for a in red_ants if math.hypot(a.x - self.x, a.y - self.y) < self.radius)
        b_count = sum(1 for a in blue_ants if math.hypot(a.x - self.x, a.y - self.y) < self.radius)

        # 佔領邏輯
        if r_count > b_count:
            self.capture_val += STRONGHOLD_CAP_SPEED
        elif b_count > r_count:
            self.capture_val -= STRONGHOLD_CAP_SPEED

        # 限制佔領值範圍 (-100 ~ 100)
        self.capture_val = max(-100, min(100, self.capture_val))

        # 判定歸屬
        if self.capture_val >= 100:
            self.owner = 'RED'
        elif self.capture_val <= -100:
            self.owner = 'BLUE'
        elif abs(self.capture_val) < 50:
            self.owner = None

        # 產出資源邏輯
        if self.owner:
            self.timer += 1
            if self.timer > STRONGHOLD_INCOME_RATE:
                self.timer = 0
                if self.owner == 'RED':
                    red_base.resources += STRONGHOLD_BASE_REWARD
                else:
                    blue_base.resources += STRONGHOLD_BASE_REWARD

    def draw(self, surface):
        # 根據歸屬改變顏色
        color = self.color_neutral
        if self.owner == 'RED':
            color = self.color_red
        elif self.owner == 'BLUE':
            color = self.color_blue

        # 繪製主體
        pygame.draw.circle(surface, color, (self.x, self.y), self.radius, width=int(4 * SCALE))
        pygame.draw.circle(surface, color, (self.x, self.y), self.radius // 3)

        # 繪製進度條 (外圈弧線)
        if self.capture_val != 0:
            start_angle = 0
            end_angle = (abs(self.capture_val) / 100) * 2 * math.pi
            rect = pygame.Rect(self.x - self.radius, self.y - self.radius, self.radius * 2, self.radius * 2)
            # 這裡簡化處理，實際Pygame畫弧線比較複雜，用文字或顏色深淺代替

        font = pygame.font.SysFont(None, int(30 * SCALE))
        txt = font.render("INF", True, WHITE)
        surface.blit(txt, (self.x - int(15 * SCALE), self.y - int(10 * SCALE)))


# ==========================================
# 🍎 食物 (Food) - [完全保留]
# ==========================================
class Food:
    def __init__(self, walls, playable_rect):
        s = int(10 * SCALE)
        self.rect = pygame.Rect(0, 0, s, s)
        self.value = 15

        # 嘗試隨機生成位置，確保不卡在牆裡
        attempts = 0
        while attempts < 100:
            self.x = random.randint(playable_rect.left, playable_rect.right)
            self.y = random.randint(playable_rect.top, playable_rect.bottom)
            self.rect.center = (self.x, self.y)
            if self.rect.collidelist([w.rect for w in walls]) == -1:
                break
            attempts += 1

    def draw(self, surface):
        pygame.draw.circle(surface, GOLD, (int(self.x), int(self.y)), int(5 * SCALE))


# ==========================================
# 🐜 螞蟻實體 (Ant) - [完全保留 + 尾部追加方法]
# ==========================================
class Ant:
    def __init__(self, team, type, x, y):
        self.team = team
        self.type = type
        self.x, self.y = float(x), float(y)
        self.has_resource = False
        self.carrying_type = None
        self.color = RED_COLOR if team == 'RED' else BLUE_COLOR

        # 初始化屬性
        if type == 'WORKER':
            self.hp = WORKER_HP;
            self.atk = WORKER_ATK;
            self.speed = WORKER_SPEED;
            self.size = WORKER_SIZE
        elif type == 'SOLDIER':
            self.hp = SOLDIER_HP;
            self.atk = SOLDIER_ATK;
            self.speed = SOLDIER_SPEED;
            self.size = SOLDIER_SIZE
        elif type == 'TANK':
            self.hp = TANK_HP;
            self.atk = TANK_ATK;
            self.speed = TANK_SPEED;
            self.size = TANK_SIZE
        elif type == 'MEDIC':
            self.hp = MEDIC_HP;
            self.atk = 0;
            self.speed = MEDIC_SPEED;
            self.size = MEDIC_SIZE
        elif type == 'SCOUT':
            self.hp = SCOUT_HP;
            self.atk = SCOUT_ATK;
            self.speed = SCOUT_SPEED;
            self.size = SCOUT_SIZE

        self.max_hp = self.hp
        self.rect = pygame.Rect(x, y, self.size, self.size)
        self.rect.center = (x, y)

        # 物理與狀態變數
        self.last_pos = (x, y)
        self.stuck_check_timer = 0
        self.escape_timer = 0
        self.escape_dir = (0, 0)
        self.attack_timer = 0

        # 任務狀態機 (用於 main.py 的高級邏輯)
        self.mission_state = 'IDLE'
        self.mission_target = None
        self.mission_timer = 0

    # -------------------------------------------------------------------------
    # 👇 [原本的物理與移動邏輯，完全保留，一行未刪] 👇
    # -------------------------------------------------------------------------

    def move_and_slide(self, target_x, target_y, walls, friends=[], cohesion_strength=0.0):
        current_speed = self.speed
        if self.carrying_type:
            factor = CARRY_SPEED_FACTOR.get(self.type, 0.7)
            current_speed *= factor

        if self.escape_timer > 0:
            self.escape_timer -= 1
            vx = self.escape_dir[0] * current_speed * 1.5
            vy = self.escape_dir[1] * current_speed * 1.5
            self.apply_physics(vx, vy, walls)
            self.clamp_to_map()
            return

        self.stuck_check_timer += 1
        if self.stuck_check_timer > 20:
            dist_moved = math.hypot(self.x - self.last_pos[0], self.y - self.last_pos[1])
            if dist_moved < 2 * SCALE:
                angle = random.uniform(0, 6.28)
                self.escape_dir = (math.cos(angle), math.sin(angle))
                self.escape_timer = 30
            self.last_pos = (self.x, self.y)
            self.stuck_check_timer = 0

        dx = target_x - self.x
        dy = target_y - self.y
        dist = math.hypot(dx, dy)
        if dist > 0:
            vx = (dx / dist) * current_speed
            vy = (dy / dist) * current_speed
        else:
            vx, vy = 0, 0

        if cohesion_strength > 0 and friends:
            avg_x, avg_y = 0, 0
            count = 0
            sep_x, sep_y = 0, 0

            sample_friends = friends if len(friends) < 10 else random.sample(friends, 10)

            for f in sample_friends:
                if f is self: continue
                d = math.hypot(self.x - f.x, self.y - f.y)
                if d < 300 * SCALE:
                    avg_x += f.x;
                    avg_y += f.y;
                    count += 1
                if d < self.size + f.size + 2:
                    push = (10 / (d + 1)) * SCALE
                    sep_x += (self.x - f.x) * push
                    sep_y += (self.y - f.y) * push

            if count > 0:
                avg_x /= count
                avg_y /= count
                coh_dx = avg_x - self.x
                coh_dy = avg_y - self.y
                coh_dist = math.hypot(coh_dx, coh_dy)
                if coh_dist > 0:
                    coh_vx = (coh_dx / coh_dist) * MAX_COHESION_FORCE * cohesion_strength
                    coh_vy = (coh_dy / coh_dist) * MAX_COHESION_FORCE * cohesion_strength
                    vx += coh_vx
                    vy += coh_vy
            vx += sep_x
            vy += sep_y

            final_speed = math.hypot(vx, vy)
            if final_speed > current_speed:
                vx = (vx / final_speed) * current_speed
                vy = (vy / final_speed) * current_speed

        margin = 60 * SCALE
        if self.x < margin:
            vx += 1 * SCALE
        elif self.x > WIDTH - margin:
            vx -= 1 * SCALE
        if self.y < margin:
            vy += 1 * SCALE
        elif self.y > HEIGHT - margin:
            vy -= 1 * SCALE

        avoid_x, avoid_y = 0, 0
        test_rect = self.rect.copy()
        test_rect.centerx += int(vx * 5)
        test_rect.centery += int(vy * 5)
        hit_index = test_rect.collidelist([w.rect for w in walls])
        if hit_index != -1:
            wall = walls[hit_index]
            if wall.rect.centerx > self.x:
                avoid_x = -ANT_AVOID_FORCE * current_speed
            else:
                avoid_x = ANT_AVOID_FORCE * current_speed
            if wall.rect.centery > self.y:
                avoid_y = -ANT_AVOID_FORCE * current_speed
            else:
                avoid_y = ANT_AVOID_FORCE * current_speed

        final_vx = vx + avoid_x
        final_vy = vy + avoid_y

        self.apply_physics(final_vx, final_vy, walls)
        self.clamp_to_map()

    def apply_physics(self, vx, vy, walls):
        hitbox = self.rect.inflate(-int(6 * SCALE), -int(6 * SCALE))
        self.x += vx
        hitbox.centerx = int(self.x)
        if hitbox.collidelist([w.rect for w in walls]) != -1:
            self.x -= vx
        self.y += vy
        hitbox.centery = int(self.y)
        if hitbox.collidelist([w.rect for w in walls]) != -1:
            self.y -= vy
        self.rect.center = (int(self.x), int(self.y))

    def clamp_to_map(self):
        self.x = max(self.size, min(WIDTH - self.size, self.x))
        self.y = max(self.size, min(HEIGHT - self.size, self.y))
        self.rect.center = (int(self.x), int(self.y))

    def draw(self, surface):
        center = (int(self.x), int(self.y))
        if self.type == 'WORKER':
            pygame.draw.circle(surface, self.color, center, self.size // 2)
        elif self.type == 'SOLDIER':
            pygame.draw.rect(surface, self.color, self.rect)
        elif self.type == 'TANK':
            half_w = self.size / 2
            top_w = half_w * 0.6
            bot_w = half_w * 1.4
            height = self.size
            p1 = (center[0] - top_w, center[1] - height / 2)
            p2 = (center[0] + top_w, center[1] - height / 2)
            p3 = (center[0] + bot_w, center[1] + height / 2)
            p4 = (center[0] - bot_w, center[1] + height / 2)
            pygame.draw.polygon(surface, self.color, [p1, p2, p3, p4])
            pygame.draw.polygon(surface, WHITE, [p1, p2, p3, p4], 2)
        elif self.type == 'MEDIC':
            pygame.draw.circle(surface, self.color, center, self.size // 2)
            pygame.draw.circle(surface, WHITE, center, self.size // 3)
            pygame.draw.line(surface, (255, 50, 50), (center[0], center[1] - 4 * SCALE),
                             (center[0], center[1] + 4 * SCALE), 2)
            pygame.draw.line(surface, (255, 50, 50), (center[0] - 4 * SCALE, center[1]),
                             (center[0] + 4 * SCALE, center[1]), 2)
        elif self.type == 'SCOUT':
            p1 = (center[0], center[1] - self.size)
            p2 = (center[0] - self.size, center[1] + self.size)
            p3 = (center[0] + self.size, center[1] + self.size)
            pygame.draw.polygon(surface, self.color, [p1, p2, p3])
            pygame.draw.polygon(surface, ORANGE, [p1, p2, p3], 2)

        if self.carrying_type == 'FOOD':
            pygame.draw.circle(surface, GOLD, (int(self.x), int(self.y - self.size)), int(3 * SCALE))
        elif self.carrying_type == 'ORB':
            pygame.draw.circle(surface, CYAN, (int(self.x), int(self.y - self.size)), int(4 * SCALE))
        elif self.carrying_type == 'STOLEN':
            pygame.draw.circle(surface, PURPLE, (int(self.x), int(self.y - self.size)), int(4 * SCALE))

        if self.hp < self.max_hp:
            r = self.hp / self.max_hp
            bar_w = int(12 * SCALE)
            pygame.draw.rect(surface, (50, 0, 0), (self.x - bar_w / 2, self.y - self.size - 2, bar_w, 3))
            pygame.draw.rect(surface, GREEN, (self.x - bar_w / 2, self.y - self.size - 2, bar_w * r, 3))

    # -------------------------------------------------------------------------
    # 🔥🔥🔥 [新增部分] AI 輔助方法 (這些是 Main.py 必須調用的) 🔥🔥🔥
    # -------------------------------------------------------------------------

    def update_cooldown(self):
        """更新攻擊冷卻"""
        if self.attack_timer > 0:
            self.attack_timer -= 1

    def get_closest_enemy(self, enemies, vision_range):
        """獲取最近的敵人"""
        closest = None
        min_dist = 9999
        for e in enemies:
            d = math.hypot(self.x - e.x, self.y - e.y)
            if d < vision_range and d < min_dist:
                min_dist = d
                closest = e
        return closest, min_dist

    def has_line_of_sight(self, target, walls):
        """[防穿牆] 檢查視線是否被牆擋住"""
        line_start = (self.x, self.y)
        line_end = (target.x, target.y)
        for wall in walls:
            if wall.rect.clipline(line_start, line_end):
                return False
        return True

    def can_attack(self, target, dist_to_target, walls, reach_bonus=0):
        """[綜合判定] 檢查是否能攻擊 (距離 + 敵我 + 視線)"""
        if not target: return False
        if target.team == self.team: return False

        # 距離檢查
        combat_range = (self.size / 2) + (target.size / 2) + (10 * SCALE) + reach_bonus
        if dist_to_target > combat_range: return False

        # 視線檢查 (防穿牆)
        if not self.has_line_of_sight(target, walls): return False

        return True

    def perform_attack(self, target, cooldown_time):
        """[執行攻擊] 扣血 + 設定冷卻"""
        if self.attack_timer == 0:
            dmg = self.atk
            # 兵種相剋
            if self.type == 'TANK':
                dmg *= TANK_BASE_DMG_MULT
            elif self.type == 'SOLDIER':
                dmg *= SOLDIER_BASE_DMG_MULT
            target.hp -= dmg
            self.attack_timer = cooldown_time
            return True
        return False

    def get_value(self):
        """[價值評估] 用於 AI 決定換命"""
        if self.type == 'MEDIC': return 50
        if self.type == 'WORKER': return 30
        if self.type == 'TANK': return 40
        if self.type == 'SOLDIER': return 20
        if self.type == 'SCOUT': return 10
        return 0


# ==========================================
# 基地 (Base) - [完全保留]
# ==========================================
class Base:
    def __init__(self, team, x, y, gene):
        self.team = team
        self.x, self.y = x, y
        self.hp = float(BASE_HP)
        self.prev_hp = float(BASE_HP)
        self.resources = 50
        self.ants = []
        self.gene = gene
        self.passive_timer = 0
        self.radius = BASE_RADIUS
        self.enemy_signals = []
        self.food_signals = []
        self.last_damage_time = 0

    def update(self):
        self.passive_timer += 1
        if self.passive_timer > PASSIVE_INCOME_RATE:
            self.passive_timer = 0
            self.resources += 1

        current_time = pygame.time.get_ticks()
        if self.hp < self.prev_hp:
            self.last_damage_time = current_time
        self.prev_hp = self.hp

        time_since_damage = current_time - self.last_damage_time
        if time_since_damage > BASE_OUT_OF_COMBAT_TIME:
            regen_rate = BASE_REGEN_IDLE
        else:
            regen_rate = BASE_REGEN_COMBAT

        if self.hp < BASE_HP:
            self.hp += regen_rate
            if self.hp > BASE_HP: self.hp = BASE_HP
            self.prev_hp = self.hp

        self.enemy_signals = [s for s in self.enemy_signals if s[2] > 0]
        self.food_signals = [s for s in self.food_signals if s[2] > 0]
        for i in range(len(self.enemy_signals)):
            self.enemy_signals[i] = (self.enemy_signals[i][0], self.enemy_signals[i][1], self.enemy_signals[i][2] - 1)
        for i in range(len(self.food_signals)):
            self.food_signals[i] = (self.food_signals[i][0], self.food_signals[i][1], self.food_signals[i][2] - 1)

    def add_enemy_signal(self, x, y):
        for s in self.enemy_signals:
            if math.hypot(s[0] - x, s[1] - y) < 50 * SCALE: return
        self.enemy_signals.append((x, y, SIGNAL_LIFE))

    def add_food_signal(self, x, y):
        for s in self.food_signals:
            if math.hypot(s[0] - x, s[1] - y) < 20 * SCALE: return
        self.food_signals.append((x, y, SIGNAL_LIFE))

    def spawn_logic(self):
        if len(self.ants) >= MAX_ANTS_PER_TEAM: return

        soldier_prob = self.gene[0]
        weights = self.gene[1:5]
        if sum(weights) == 0: weights = [1, 1, 1, 1]

        cost = 0;
        new_type = 'WORKER'

        worker_count = sum(1 for a in self.ants if a.type == 'WORKER')
        force_worker = (worker_count < 2)

        if not force_worker and random.random() < soldier_prob:
            choice = random.choices(['SOLDIER', 'TANK', 'MEDIC', 'SCOUT'], weights=weights, k=1)[0]
            if choice == 'SOLDIER':
                cost = SOLDIER_COST;
                new_type = 'SOLDIER'
            elif choice == 'TANK':
                cost = TANK_COST;
                new_type = 'TANK'
            elif choice == 'MEDIC':
                cost = MEDIC_COST;
                new_type = 'MEDIC'
            elif choice == 'SCOUT':
                cost = SCOUT_COST;
                new_type = 'SCOUT'
        else:
            cost = WORKER_COST;
            new_type = 'WORKER'

        if self.resources >= cost:
            self.resources -= cost
            self.ants.append(Ant(self.team, new_type, self.x, self.y))

    def draw(self, surface):
        color = RED_COLOR if self.team == 'RED' else BLUE_COLOR
        pygame.draw.circle(surface, color, (self.x, self.y), self.radius)
        hp_width = self.radius * 2
        pygame.draw.rect(surface, GREEN,
                         (self.x - self.radius, self.y - self.radius - 10, hp_width * (self.hp / BASE_HP), 6))
        font = pygame.font.SysFont(None, int(24 * SCALE))
        img = font.render(f"${int(self.resources)}", True, WHITE)
        surface.blit(img, (self.x - 15, self.y + self.radius + 5))


# ==========================================
# ⚙️ 環境重置 (Reset Environment) - [完全保留]
# ==========================================
def reset_game_environment(mode, r_gene, b_gene):
    walls = []
    max_cols = WIDTH // BLOCK_SIZE
    max_rows = HEIGHT // BLOCK_SIZE

    start_col, end_col = 0, max_cols
    start_row, end_row = 0, max_rows

    if mode == 'RANDOM':
        actual_cols = random.randint(10, max_cols)
        actual_rows = random.randint(8, max_rows)
        padding_w = (max_cols - actual_cols) // 2
        padding_h = (max_rows - actual_rows) // 2
        start_col = padding_w
        end_col = start_col + actual_cols
        start_row = padding_h
        end_row = start_row + actual_rows

    playable_rect = pygame.Rect(
        start_col * BLOCK_SIZE, start_row * BLOCK_SIZE,
        (end_col - start_col) * BLOCK_SIZE, (end_row - start_row) * BLOCK_SIZE
    )

    cols = end_col - start_col
    rows = end_row - start_row
    if cols % 2 == 0: cols -= 1
    if rows % 2 == 0: rows -= 1

    if mode == 'RANDOM':
        erosion_rate = random.uniform(MAZE_EROSION_MIN, MAZE_EROSION_MAX)
        print(f"Map Complexity (Erosion Rate): {erosion_rate:.2f}")
        gen = MazeGenerator(cols, rows, erosion_rate)
        grid = gen.generate()

        THICKNESS_RATIO = 0.4
        thickness = int(BLOCK_SIZE * THICKNESS_RATIO)
        offset = int((BLOCK_SIZE - thickness) / 2)

        for r in range(rows):
            for c in range(cols):
                if grid[r][c] == 1:
                    wx = (start_col + c) * BLOCK_SIZE
                    wy = (start_row + r) * BLOCK_SIZE

                    has_top = (r > 0 and grid[r - 1][c] == 1)
                    has_bottom = (r < rows - 1 and grid[r + 1][c] == 1)
                    has_left = (c > 0 and grid[r][c - 1] == 1)
                    has_right = (c < cols - 1 and grid[r][c + 1] == 1)
                    is_h = (has_left or has_right) and not (has_top or has_bottom)
                    is_v = (has_top or has_bottom) and not (has_left or has_right)

                    if is_h:
                        walls.append(Wall(wx, wy + offset, BLOCK_SIZE, thickness))
                    elif is_v:
                        walls.append(Wall(wx + offset, wy, thickness, BLOCK_SIZE))
                    else:
                        walls.append(Wall(wx + offset, wy + offset, thickness, thickness))
                        if has_top: walls.append(Wall(wx + offset, wy, thickness, offset))
                        if has_bottom: walls.append(Wall(wx + offset, wy + offset + thickness, thickness, offset))
                        if has_left: walls.append(Wall(wx, wy + offset, offset, thickness))
                        if has_right: walls.append(Wall(wx + offset + thickness, wy + offset, offset, thickness))
    else:
        for y in range(rows):
            for x in range(cols):
                if x == 0 or y == 0 or x == cols - 1 or y == rows - 1:
                    wx = (start_col + x) * BLOCK_SIZE
                    wy = (start_row + y) * BLOCK_SIZE
                    walls.append(Wall(wx, wy, BLOCK_SIZE, BLOCK_SIZE))

    def get_random_base_pos(exclude_pos=None):
        max_attempts = 2000
        for _ in range(max_attempts):
            margin = BASE_RADIUS + int(30 * SCALE)
            bx = random.randint(playable_rect.left + margin, playable_rect.right - margin)
            by = random.randint(playable_rect.top + margin, playable_rect.bottom - margin)
            temp_rect = pygame.Rect(bx - BASE_RADIUS, by - BASE_RADIUS, BASE_RADIUS * 2, BASE_RADIUS * 2)
            if temp_rect.collidelist([w.rect for w in walls]) != -1: continue
            if exclude_pos:
                dist = math.hypot(bx - exclude_pos[0], by - exclude_pos[1])
                min_dist = math.hypot(playable_rect.width, playable_rect.height) * 0.5
                if dist < min_dist: continue
            return bx, by
        return playable_rect.centerx, playable_rect.centery

    red_x, red_y = get_random_base_pos()
    blue_x, blue_y = get_random_base_pos(exclude_pos=(red_x, red_y))

    def clear_area(cx, cy, radius_blocks=4):
        center_rect = pygame.Rect(cx - radius_blocks * BLOCK_SIZE, cy - radius_blocks * BLOCK_SIZE,
                                  radius_blocks * 2 * BLOCK_SIZE, radius_blocks * 2 * BLOCK_SIZE)
        walls[:] = [w for w in walls if not w.rect.colliderect(center_rect)]

    base_clear_r = int(BASE_RADIUS / BLOCK_SIZE) + 4
    clear_area(red_x, red_y, base_clear_r)
    clear_area(blue_x, blue_y, base_clear_r)

    red_base = Base('RED', red_x, red_y, r_gene)
    blue_base = Base('BLUE', blue_x, blue_y, b_gene)

    area_ratio = (playable_rect.width * playable_rect.height) / (WIDTH * HEIGHT)
    actual_strongholds = max(3, int(STRONGHOLD_COUNT * area_ratio * random.uniform(0.8, 1.2)))
    actual_food = int(ONE_TIME_FOOD_COUNT * area_ratio * random.uniform(0.8, 1.5))

    strongholds = []
    attempts = 0
    min_dist_to_base = 150 * SCALE

    while len(strongholds) < actual_strongholds and attempts < 1000:
        attempts += 1
        margin = STRONGHOLD_RADIUS + int(20 * SCALE)
        sx = random.randint(playable_rect.left + margin, playable_rect.right - margin)
        sy = random.randint(playable_rect.top + margin, playable_rect.bottom - margin)
        temp_rect = pygame.Rect(sx - STRONGHOLD_RADIUS, sy - STRONGHOLD_RADIUS, STRONGHOLD_RADIUS * 2,
                                STRONGHOLD_RADIUS * 2)
        if temp_rect.collidelist([w.rect for w in walls]) != -1: continue

        if math.hypot(sx - red_base.x, sy - red_base.y) < min_dist_to_base: continue
        if math.hypot(sx - blue_base.x, sy - blue_base.y) < min_dist_to_base: continue
        if any(math.hypot(sx - s.x, sy - s.y) < 250 * SCALE for s in strongholds): continue

        sh_clear_r = int(STRONGHOLD_RADIUS / BLOCK_SIZE) + 2
        clear_area(sx, sy, sh_clear_r)
        strongholds.append(Stronghold(sx, sy))

    foods = [Food(walls, playable_rect) for _ in range(actual_food)]

    return red_base, blue_base, walls, foods, strongholds