import pygame
import sys

# 初始化
pygame.init()

# 如果這一步報錯，說明你的 WSL 不支持圖形界面
try:
    screen = pygame.display.set_mode((400, 300))
    pygame.display.set_caption("WSL GUI Test")
except pygame.error as e:
    print(f"❌ 圖形界面啟動失敗: {e}")
    print("💡 提示: 你的 WSL 可能需要配置 X-Server (如 VcXsrv) 或者升級到 WSL 2。")
    sys.exit(1)

print("✅ 成功！你應該能看到一個黑色小窗口。")
print("按窗口右上角的 X 關閉它。")

# 循環保持窗口不關閉
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

pygame.quit()